from returning import RandomWalk, has_returned, get_Prob, m_results

m_results(10)
